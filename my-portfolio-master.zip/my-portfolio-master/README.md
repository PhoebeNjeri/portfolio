# Alex Portfolio

#### Author
* Alex Otieno

#### Description
* This website is create to show users my portfolio and work

#### Setup Requirements
* Install it for run

#### Live Demo
* https://alexotieno1717.github.io/my-portfolio/

#### Technologies Used
* HTML 5
* CSS 3

#### License
* MIT © Alex Otieno